import sys
from fontTools.mtiLib import main

if __name__ == '__main__':
	sys.exit(main())
