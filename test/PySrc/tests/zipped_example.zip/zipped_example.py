def foo(x):
    return f'passed {x} to foo()'
